<x-app-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container mx-auto whitespace-nowrap bg-white overflow-hidden p-8 rounded-lg">
        <form class="m-2" method="POST" action="{{ route('save-theater-data') }}" enctype="multipart/form-data">
            @csrf
            <x-validation-errors class="mb-4" />
            @if (session('status'))
                <div class="text-lg text-green-600">
                    {{ session('status') }}
                </div>
            @endif
            @php
                $button = ($id == 'new') ? 'Add' : 'Update';
            @endphp

            <input type="hidden" id="id" name="id" value="{{ $theater->id ?? '' }}" />
            <div class="grid mx-8 mt-4">
                <div class="mt-4 flex justify-around">
                    <x-label class="w-3/12 text-xl md:font-bold" for="name" value="{{ __('Theater Name') }}" />
                    <x-input class="w-6/12" id="name" type="text" name="name" value="{{ old('name', $theater->name ?? '') }}" required />
                </div>
                <div class="mt-4 flex justify-around">
                    <x-label class="w-3/12 text-xl md:font-bold" for="location" value="{{ __('Location') }}" />
                    <x-input id="location" class="w-6/12" type="text" name="location" value="{{ old('location', $theater->location ?? '') }}" required />
                </div>
                <div class="mt-4 ml-2">
                <x-button class="ml-20 px-6">
                    {{ $button }}
                </x-button>
            </div>
                @if ($id != 'new') {{-- Check if editing, then show screen details --}}
                @if ($theater->screens)
                        <div class="mt-4">
                            <x-label class="text-xl md:font-bold" value="{{ __('Screens') }}" />
                            <table class="mt-2 w-full border">
                                <thead>
                                    <tr>
                                        <th class="p-2 border">Screen Name</th>
                                        <th class="p-2 border">Capacity</th>
                                        <th class="p-2 border">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($theater->screens as $screen)
                                        <tr>
                                            <td class="p-2 border">{{ $screen->name }}</td>
                                            <td class="p-2 border">{{ $screen->capacity }}</td>
                                            <td class="p-2 border">
                                            <a href="#" class="text-blue-500 hover:underline" onclick="editScreen('{{ $screen->id }}')">Edit</a>
                                        <a href="#" class="text-red-500 hover:underline" onclick="deleteScreen('{{ $screen->id }}')">Delete</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                @endif
        </form>
    </div>
</x-app-layout>

